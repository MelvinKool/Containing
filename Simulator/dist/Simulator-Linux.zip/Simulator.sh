#!/bin/sh
java  -jar Simulator.jar
        